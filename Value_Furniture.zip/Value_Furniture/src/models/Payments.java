package models;

import java.util.Date;

public class Payments {
    private int paymentsId;
    private String companyId;
    private String companyName;
    private double total;
    private Date date;
    private String cardNumber;
    private String expireDate;
    private String cvc;

    // Constructors
    public Payments() {
        // Default constructor
    }

    public Payments(int paymentsId, String companyId, String companyName, double total, Date date, String cardNumber, String expireDate, String cvc) {
        this.paymentsId = paymentsId;
        this.companyId = companyId;
        this.companyName = companyName;
        this.total = total;
        this.date = date;
        this.cardNumber = cardNumber;
        this.expireDate = expireDate;
        this.cvc = cvc;
    }

    // Getters and setters
    public int getPaymentsId() {
        return paymentsId;
    }

    public void setPaymentsId(int paymentsId) {
        this.paymentsId = paymentsId;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getExpireDate() {
        return expireDate;
    }

    public void setExpireDate(String expireDate) {
        this.expireDate = expireDate;
    }

    public String getCvc() {
        return cvc;
    }

    public void setCvc(String cvc) {
        this.cvc = cvc;
    }
}
