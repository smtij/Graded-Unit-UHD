package models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Staff extends User {

    // Attributes
    private int staffId;
    private String position;
    private double salary;
    private String staffEmail; // Add StaffEmail attribute
    private Map<Integer, Order> orders; // Use Map interface for flexibility
    private static List<Staff> staffList = new ArrayList<>(); // Use List interface for flexibility

    // Constructors
    public Staff() {
        super();
        position = "";
        salary = 0;
        staffEmail = ""; // Initialize StaffEmail
        orders = new HashMap<>();
    }

    public Staff(String usernameIn, String passwordIn, String firstNameIn, String lastNameIn, String positionIn, double salaryIn, String staffEmailIn) {
        super(usernameIn, passwordIn, firstNameIn, lastNameIn);
        position = positionIn;
        salary = salaryIn;
        staffEmail = staffEmailIn; // Initialize StaffEmail
        orders = new HashMap<>();
    }

    public Staff(String usernameIn, String passwordIn, String firstNameIn, String lastNameIn, String positionIn, double salaryIn, String staffEmailIn, Map<Integer, Order> orders) {
        super(usernameIn, passwordIn, firstNameIn, lastNameIn);
        position = positionIn;
        salary = salaryIn;
        staffEmail = staffEmailIn; // Initialize StaffEmail
        this.orders = new HashMap<>(orders);
    }

    // Getters and setters
    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public int getStaffId() {
        return staffId;
    }

    public void setStaffId(int staffId) {
        this.staffId = staffId;
    }

    public String getStaffEmail() {
        return staffEmail;
    }

    public void setStaffEmail(String staffEmail) {
        this.staffEmail = staffEmail;
    }

    public Map<Integer, Order> getOrders() {
        return orders;
    }

    public void setOrders(Map<Integer, Order> orders) {
        this.orders = orders;
    }

    // Static methods for managing staff list
    public static List<Staff> getAllStaff() {
        return staffList;
    }

    public static synchronized void addStaff(String userName, String password, String firstName, String lastName, String position, double salary, String staffEmail) {
        Staff staff = new Staff(userName, password, firstName, lastName, position, salary, staffEmail);
        staffList.add(staff);
    }

    public static synchronized void deleteStaff(String userName) {
        staffList.removeIf(staff -> staff.getUsername().equals(userName));
    }

    public static synchronized void editStaff(String userName, String newPassword, String newFirstName, String newLastName, String newPosition, double newSalary, String newStaffEmail) {
        for (Staff staff : staffList) {
            if (staff.getUsername().equals(userName)) {
                staff.setPassword(newPassword);
                staff.setFirstName(newFirstName);
                staff.setLastName(newLastName);
                staff.setPosition(newPosition);
                staff.setSalary(newSalary);
                staff.setStaffEmail(newStaffEmail);
                break;
            }
        }
    }

    // Other methods
    @Override
    public String getUsername() {
        return super.getUsername();
    }

    public String displayGreeting() {
        String greeting = "<html>Welcome " + this.getFirstName() + " " + this.getLastName() + "<br> You Are Logged In As A ";
        if (position.equals("Manager")) {
            greeting += " Manager";
        } else {
            greeting += " Staff";
        }
        greeting += "</html>";
        return greeting;
    }
}