/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

import java.util.HashMap;

/**
 *
 * @author Jason
 */
public class Manager extends User{
   

/**
 *
 * @author 30190531
 */
 
    //Attributes
    private String position;
    private double salary;
    private HashMap<Integer, Order> orders;
    public String displayGreeting()
    {
       String greeting = "<html>Welcome "+ this.getFirstName()+ " " + this.getLastName() + "<br> You Are Logged In As A ";
       if (position.equals("Manager")){
           greeting = greeting + " Manager";
       }else{
           greeting = greeting + " Staff";
       }
       greeting = greeting + "</html>";
       return greeting;
    }
    //getter methods
    public String getPosition(){
        return position;
    }
    public double getSalary(){
        return salary;
    }
    
    public HashMap<Integer, Order> getOrders() {
        return orders;
    }
    
    //setter methods
    public void setPosition(String positionIn){
        position = positionIn;
    }
    public void setSalary(double salaryIn){
        salary = salaryIn;
    }
    
    public void setOrders(HashMap<Integer, Order> orders) {
        this.orders = orders;
    }

    //constructor 0-parameter
    public Manager(String userName){
        super();
        position = "";
        salary = 0;
         orders = new HashMap<>();
    }
    
    //constructor 6-parameter
    public Manager(String usernameIn,String passwordIn,String firstNameIn,String lastNameIn,String positionIn,double salaryIn){
        super( usernameIn, passwordIn, firstNameIn, lastNameIn);
        position = positionIn;
        salary = salaryIn;
        orders = new HashMap<>(); 
    }
    public Manager(String usernameIn, String passwordIn, String firstNameIn, String lastNameIn, String positionIn, double salaryIn, HashMap<Integer, Order> orders) {
    super(usernameIn, passwordIn, firstNameIn, lastNameIn);
    position = positionIn;
    salary = salaryIn;
    this.orders = new HashMap<>();
}
}


