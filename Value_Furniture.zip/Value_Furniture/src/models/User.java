package models;

/**
 *
 * @author 30190531
 */
public class User {
    //Attributes
    private String username ;
    private String password ;
    private String firstName ;
    private String lastName ;
    
    //getter methods
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    //setter methods
    public void setUsername(String usernameIn){
        username = usernameIn;
    }
    public void setPassword(String passwordIn){
        password = passwordIn;
    }
    public void setFirstName(String firstNameIn){
        firstName = firstNameIn;
    }
    public void setLastName(String lastNameIn){
        lastName = lastNameIn;
    }
    //constructor 0-parameter
    public User(){
        username = "";
        password = "";
        firstName = "";
        lastName = "";
    }
    //constructor 4-parameter
    public User(String usernameIn,String passwordIn,String firstNameIn,String lastNameIn){
        username = usernameIn;
        password = passwordIn;
        firstName = firstNameIn;
        lastName = lastNameIn;
    }
}
