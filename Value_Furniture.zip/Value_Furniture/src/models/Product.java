package models;

/**
 *
 * @author 30190531
 */
public class Product {
    //Attributes
    private int productId;
    private String productName;
    private double price;
    private int stockLevel;
    private String measurement;
    private int quantity;
    private Category category;
    /**
     *
     * @return
     */
    @Override
    public String toString()
    {
        String display = productName;
        return display;
    }
    
    
    // Getter methods
    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public double getPrice() {
        return price;
    }

    public int getStockLevel() {
        return stockLevel;
    }

    public String getMeasurement() {
        return measurement;
    }

    public int getQuantity() {
        return quantity;
    }
     
     public Category getCategory() {
        return category;
    }
    // Setter methods
    public void setProductId(int productIdIn) {
        productId = productIdIn;
    }

    public void setProductName(String productNameIn) {
        productName = productNameIn;
    }

    public void setPrice(double priceIn) {
        price = priceIn;
    }

    public void setStockLevel(int stockLevelIn) {
        stockLevel = stockLevelIn;
    }

    public void setMeasurement(String measurementIn) {
    measurement = measurementIn;
}

    public void setQuantity(int quantityIn) {
        quantity = quantityIn;
    }
    
    public void setCategory(Category category) {
        this.category = category;
    }

    // Additional method for staff to edit product
    public void staffEditProduct(String productNameIn, double priceIn, int stockLevelIn, String measurementIn) {
        productName = productNameIn;
        price = priceIn;
        stockLevel = stockLevelIn;
        measurement = measurementIn;
    }

    // Constructors
    // 0-parameter constructor
    public Product() {
        productId = 0;
        productName = "";
        price = 0;
        stockLevel = 0;
        measurement = "";
    }

    // 3-parameter constructor
    public Product(String productNameIn, double priceIn, int stocklevelIn) {
        productId = 0;
        productName = productNameIn;
        price = priceIn;
        stockLevel = stocklevelIn;
        measurement = "";
    }

    // 4-parameter constructor
    public Product(int productIdIn, String productNameIn, double priceIn, int stockLevelIn) {
        productId = productIdIn;
        productName = productNameIn;
        price = priceIn;
        stockLevel = stockLevelIn;
        measurement = "";
    }
    
     // Constructor with parameters

    /**
     *
     * @param productName
     * @param price
     * @param stockLevel
     * @param category
     */
    public Product(String productName, double price, int stockLevel, Category category) {
        this.productName = productName;
        this.price = price;
        this.stockLevel = stockLevel;
        this.category = category;
    }
}