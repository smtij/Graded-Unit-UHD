package models;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Order {
    
    private int orderId;
    private Date orderDate;
    private double orderTotal;
    private String status;
    private HashMap<Integer, OrderLine> orderLines;
    private String companyName;
    private int staffId;
    private List<Product> products;
   
    public boolean removeProduct(int productId) {
         // Use Iterator to safely remove from HashMap during iteration
    Iterator<Map.Entry<Integer, OrderLine>> iterator = orderLines.entrySet().iterator();
    while (iterator.hasNext()) {
        Map.Entry<Integer, OrderLine> entry = iterator.next();
        if (entry.getValue().getProduct().getProductId() == productId) {
            iterator.remove();
            return true; // Product found and removed
        }
    }
    return false;
        }
    
    
    public double calculateOrderTotal(){
        orderTotal = 0;
        
        for(Map.Entry<Integer, OrderLine> olMapEntry : orderLines.entrySet()) {
            OrderLine ol = olMapEntry.getValue();
            orderTotal = orderTotal + ol.getLineTotal();
        }
        return orderTotal;
    } 
    
    public void addOrderLine(OrderLine ol) {
        int orderLineId = 0;
        
        while (orderLines.containsKey(orderLineId)) {
            orderLineId++;
        }
        ol.setOrderLineId(orderLineId);
        orderLines.put(orderLineId, ol);
    }
    
    // Method to get the customer name associated with the order
    public String getCompanyName() {
        return companyName != null ? companyName : "Unknown";
    }
    
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    // Method to calculate and return the total order amount
    public double getTotal() {
        return orderTotal;
    }
    
    // Getters and setters for all attributes
    public HashMap<Integer, OrderLine> getOrderLines() {
        return orderLines;
    }

    public void setOrderLines(HashMap<Integer, OrderLine> orderLinesIn) {
        orderLines = orderLinesIn;
    }

    public int getOrderId() {
        return orderId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public double getOrderTotal() {
        return orderTotal;
    }

    public String getStatus() {
        return status;
    }

    public void setOrderId(int inOrderId) {
        orderId = inOrderId;
    }

    public void setOrderDate(Date inOrderDate) {
        orderDate = inOrderDate;
    }

    public void setOrderTotal(double inOrderTotal) {
        orderTotal = inOrderTotal;
    }

    public void setStatus(String inStatus) {
        status = inStatus;
    }

    // Constructor - 4 parameters , all except orderlines
    public Order(int orderIdIn, Date orderDateIn, double orderTotalIn, String statusIn) {
        orderId = orderIdIn;
        orderDate = orderDateIn;
        orderTotal = orderTotalIn;
        status = statusIn;
        orderLines = new HashMap<>();
        products = new ArrayList<>(); // Initialize the products list
    }

    // Constructor - 0 parameters
    public Order() {
        orderId = 0;
        orderDate = new Date();
        orderTotal = 0;
        status = "In Progress";
        orderLines = new HashMap<>();
        products = new ArrayList<>(); // Initialize the products list
    }
    
    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
}
