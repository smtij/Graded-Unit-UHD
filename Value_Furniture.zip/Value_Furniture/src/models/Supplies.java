package models;

/**
 *
 * @author 30190531
 */
public class Supplies extends Product{
    //Attributes
    private String size;
    //getter methods
    public String getSize(){
        return size;
    }
    //setter methods
    public void setSize(String sizeIn){
        size = sizeIn;
    }
    //constructor 0-parameter
    public Supplies(){
        super();
        size = "";
    }
    //constructor 4-parameter everything EXCEPT productId
    public Supplies(String productNameIn,double priceIn,int StockLevelIn,String sizeIn){
        super( productNameIn, priceIn, StockLevelIn);
        size = sizeIn;
    }
    
      // Constructor with 5 parameters (including productId)
    public Supplies(int productIdIn, String productNameIn, double priceIn, int stockLevelIn, String sizeIn) {
        super(productIdIn, productNameIn, priceIn, stockLevelIn);
        size = sizeIn;
    }
    //constructor 5-parameter everything 
    public Supplies(int productIdIn,String productNameIn,double priceIn,int StockLevelIn, String measurementIn,String sizeIn){
        super(productIdIn, productNameIn, priceIn, StockLevelIn);
        size = sizeIn;
    }
}
