package models;

/**
 *
 * @author 30190531
 */
public class Furniture extends Product {
    
    // Attributes
    private String measurement;

    // Getter methods
    @Override
    public String getMeasurement() {
        return measurement;
    }

    // Setter methods

    /**
     *
     * @param measurementIn
     */
    @Override
    public void setMeasurement(String measurementIn) {
        measurement = measurementIn;
    }

    // Constructors
    // 0-parameter constructor
    

    // Constructor with 4 parameters (everything EXCEPT productId)
    public Furniture(int StockLevelIn, String productNameIn, double priceIn, String measurementIn) {
        super(productNameIn, priceIn, StockLevelIn);
        measurement = measurementIn;
    }

    // Constructor with 5 parameters (everything)
    public Furniture(int productIdIn, String productNameIn, double priceIn, int StockLevelIn, String measurementIn) {
        super(productIdIn, productNameIn, priceIn, StockLevelIn);
        measurement = measurementIn;
    }
    
    public Furniture(String productName, double price, int stockLevel, String measurement) {
        super(productName, price, stockLevel);
        this.measurement = measurement;
    }
}

