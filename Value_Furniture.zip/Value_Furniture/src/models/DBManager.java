package models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.table.DefaultTableModel;

public class DBManager {
    
    // JDBC driver and connection string
    private final String driver = "net.ucanaccess.jdbc.UcanaccessDriver";
    private final String connectionString = "jdbc:ucanaccess://Data\\ShopDB.accdb";
    
    // Constructor to load the JDBC driver
    public DBManager() {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            System.out.println("UCanAccess driver not found.");
            ex.printStackTrace();
        }
    }

    // Method to establish a database connection
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(connectionString);
    }
    
    // Method to load customer order lines from the database
    public HashMap<String, Customer> loadCustomerOrderLines(HashMap<String,Customer> customers){
        // Create a new instance of DBManager to access database methods
        DBManager db = new DBManager();
        // Load products from the database
        HashMap<Integer, Product> products = db.loadProducts();
        
        try
        {
            // Establish database connection
            Connection conn = DriverManager.getConnection(connectionString);
            Statement statement = conn.createStatement();
            
            // Execute query to retrieve order lines
            ResultSet rs = statement.executeQuery("SELECT * From OrderLines");

            while(rs.next()) // Iterate over each row in the result set
            {
                // Extract data from the result set
                int orderLineId = rs.getInt("OrderLineId");
                int productId = rs.getInt("ProductId");  
                int quantity = rs.getInt("Quantity");  
                double lineTotal = rs.getInt("LineTotal");  
                int orderId = rs.getInt("OrderId");
                
                // Create a new Product object for the current order line
                Product currentProduct = new Product();
                
                // Check if the product is already loaded, if yes, retrieve it
                if (products.containsKey(productId))
                {
                    currentProduct = products.get(productId);
                }
                
                // Create an OrderLine object
                OrderLine orderLine = new OrderLine(orderLineId, currentProduct, quantity, lineTotal);
                
                // Iterate over customers to find the customer who placed the order
                for(Map.Entry<String, Customer> cmEntry : customers.entrySet())
                {
                    Customer currentCustomer = cmEntry.getValue();
                    // Check if the customer has the order in their list of orders
                    if(currentCustomer.getOrders().containsKey(orderId))
                    {
                        // Retrieve the order and add the order line to it
                        Order orderForOrderLine = currentCustomer.getOrders().get(orderId);
                        orderForOrderLine.getOrderLines().put(orderLineId, orderLine);
                    }
                }
            }
        }
        catch(Exception ex)
        {
            System.out.println("Error loading orderlines: " + ex.getMessage());
        }
        finally
        {
            // Return the updated customers HashMap
            return customers;
        }
    }

    // Method to load customer orders from the database
    public HashMap<String, Customer> loadCustomerOrder(HashMap<String, Customer> customers)
    {
        try
        {
            // Establish database connection
            Connection conn = DriverManager.getConnection(connectionString);
            Statement statement = conn.createStatement();
            
            // Execute query to retrieve orders
            ResultSet rs = statement.executeQuery("SELECT * From Orders");

            while(rs.next()) // Iterate over each row in the result set
            {
                // Extract data from the result set
                int orderId = rs.getInt("OrderId");                
                Date orderDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(rs.getString("OrderDate"));
                  
                String companyName = rs.getString("CompanyName");
                double orderTotal = rs.getDouble("OrderTotal");            
                String status = rs.getString("Status");
                
                // Create a new Order object
                Order order = new Order(orderId, orderDate, orderTotal, status);
                
                // Check if the customer exists
                if(customers.containsKey(companyName))
                {
                    // Retrieve the customer and add the order to their list of orders
                    Customer cm = customers.get(companyName);
                    cm.getOrders().put(orderId, order);
                }
            }
        }
        catch(Exception ex)
        {
            System.out.println("Error loading orders: " + ex.getMessage());
        }
        finally
        {
            // Return the updated customers HashMap
            return customers;
        }
    }

    // Method to load order lines for a specific order from the database
    public void loadOrderLines(int orderId, Order order) {
        try {
            // Establish database connection
            Connection conn = DriverManager.getConnection(connectionString);
            Statement smt = conn.createStatement();
            // Execute query to retrieve order lines for the specified order
            ResultSet rs = smt.executeQuery("SELECT * FROM OrderLines WHERE OrderId = " + orderId);
            while(rs.next()) {
                // Extract data from the result set
                int orderLineId = rs.getInt("OrderLineId");
                int productId = rs.getInt("ProductId");
                int quantity = rs.getInt("Quantity");
                double lineTotal = rs.getDouble("LineTotal");
            }
        } catch (SQLException ex) {
            System.out.println("Error loading order lines: " + ex.getMessage());
        }
    }

    // Method to edit product details in the database
    public void editProduct(Product product) throws SQLException, ClassNotFoundException {
        try {
            // Establish database connection
            Connection conn = DriverManager.getConnection(connectionString);
            Statement statement = conn.createStatement();
            // Update product details based on the product type
            if (product instanceof Furniture) {
                // Cast product to Furniture type
                Furniture clothing = (Furniture) product;
                // Execute SQL update statement
                statement.executeUpdate("UPDATE Products SET "
                        + "ProductName = '" + clothing.getProductName() + "', "
                        + "Price = " + clothing.getPrice() + ", "
                        + "StockLevel = " + clothing.getStockLevel() + ", "
                        + "Measurements = '" + clothing.getMeasurement() + "'"
                        + " WHERE ProductId = " + clothing.getProductId());
            } else if (product instanceof Supplies) {
                // Cast product to Supplies type
                Supplies footwear = (Supplies) product;
                // Execute SQL update statement
                statement.executeUpdate("UPDATE Products SET "
                        + "ProductName = '" + footwear.getProductName() + "', "
                        + "Price = " + footwear.getPrice() + ", "
                        + "StockLevel = " + footwear.getStockLevel() + ", "
                        + "Size = " + footwear.getSize()
                        + " WHERE ProductId = " + footwear.getProductId());
            }
        } catch (Exception ex) {
            System.out.println("Error updating product details; " + ex.getMessage());
        }
    }


    // Method to update the stock level of a product in the database
    public void updateProductStockLevel(int productId, int quantity) {
       try {
            // Establish database connection
            Connection conn = DriverManager.getConnection(connectionString);
            Statement statement = conn.createStatement();
            // Execute SQL update statement to decrease stock level
            String sqlQuery = "UPDATE Products SET StockLevel = GREATEST(0, StockLevel - " + quantity + ") WHERE ProductId = " + productId;
            statement.executeUpdate(sqlQuery);
            statement.close();
            conn.close();
        } catch (SQLException ex) {
            System.out.println("Error updating stock level: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // Method to update product details in the database
    public void updateProduct(Product product, int quantity, int productId) {
    try {
        // Establish database connection
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(connectionString);
        Statement statement = conn.createStatement();
        // Calculate new stock level
        int newStockLevel = product.getStockLevel() - quantity;
        newStockLevel = Math.max(0, newStockLevel);
        // Construct SQL query based on product type
        String sqlQuery = "UPDATE Products SET "
                + "ProductName = '" + product.getProductName() + "', "
                + "Price = " + product.getPrice() + ", "
                + "StockLevel = " + newStockLevel;
        if (product instanceof Furniture) {
            // Cast product to Furniture type
            Furniture furniture = (Furniture) product;
            // Append additional fields for Furniture type
            sqlQuery += ", Measurement = '" + furniture.getMeasurement() + "'";
        } else if (product instanceof Supplies) {
            // Cast product to Supplies type
            Supplies supplies = (Supplies) product;
            // Append additional fields for Supplies type
            if (supplies.getSize() != null) {
                sqlQuery += ", Size = '" + supplies.getSize() + "'";
            } else {
                sqlQuery += ", Size = NULL";
            }
        }
        // Add WHERE clause to specify the product ID
        sqlQuery += " WHERE ProductId = " + productId;
        // Execute SQL update statement
        statement.executeUpdate(sqlQuery);
        statement.close();
        conn.close();
    } catch (SQLException ex) {
        System.out.println("Error updating product details: " + ex.getMessage());
        ex.printStackTrace();
    } catch (ClassNotFoundException ex) {
        System.out.println("Error loading JDBC driver: " + ex.getMessage());
        ex.printStackTrace();
        }
    }  

    // Method to delete a product from the database
    public void deleteProduct(Product product) {
        try {
            // Establish database connection
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(connectionString);
            Statement Statement = conn.createStatement();
            // Execute SQL delete statement
            Statement.executeUpdate("DELETE From Products WHERE ProductID = " + product.getProductId());
        } catch(Exception ex){
            System.out.println("Error deleting product: "+ ex.getMessage());
        }
    }

    // Method to load products from the database
    public HashMap<Integer, Product> loadProducts() {
    HashMap<Integer, Product> loadProducts = new HashMap<>();
    try {
        // Establish database connection
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(connectionString);
        Statement smt = conn.createStatement();
        // Execute SQL query to retrieve products
        ResultSet rs = smt.executeQuery("SELECT * FROM Products");
        while (rs.next()) {
            // Extract data from the result set
            int productId = rs.getInt("ProductId");
            String productName = rs.getString("ProductName");
            double price = rs.getDouble("Price");
            int stockLevel = rs.getInt("StockLevel");
            String measurement = rs.getString("Measurement");
            String size = rs.getString("Size"); 
            // Check product type and create corresponding object
            if (measurement != null && !measurement.isEmpty()) {
                Furniture furniture = new Furniture(productId, productName, price, stockLevel, measurement);
                loadProducts.put(productId, furniture);
            } else {
                Supplies supplies = new Supplies(productId, productName, price, stockLevel, "", size);
                loadProducts.put(productId, supplies);
            }
        }
    } catch (Exception ex) {
        System.out.println("Error loading products: " + ex.getMessage());
    } finally {
        return loadProducts;
    }
}

// Method to write an order line to the database
public void writeOrderLine(OrderLine ol, int orderId) {
    int orderLineId = 0;
    try {
        // Establish database connection
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(connectionString);
        Statement smt = conn.createStatement();
        // Execute SQL insert statement to add order line
        smt.executeUpdate("INSERT INTO OrderLines (ProductId, Quantity, LineTotal, OrderId) VALUES("
                + "'" + ol.getProduct().getProductId() + "',"
                + "'" + 1 + "',"
                +"'" + ol.getLineTotal() + "',"
                +"'" + orderId + "'"
                +")"
        );
        ResultSet rs = smt.getGeneratedKeys();
        if(rs.next()) {
            orderLineId = rs.getInt(1);
        }
        ol.setOrderLineId(orderId);
    } catch(Exception ex){
        System.out.println("Error writing orderline: "+ ex.getMessage());
    }
}

// Method to write an order to the database and return the generated order ID
public int writeOrder(Order o, String companyName) {
    int orderId = 0;
    try {
        // Establish database connection
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(connectionString);
        Statement smt = conn.createStatement();
        // Execute SQL insert statement to add order
        smt.executeUpdate("INSERT INTO Orders (OrderDate, CompanyName, OrderTotal, Status) VALUES("
                + "'" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(o.getOrderDate()) + "',"
                + "'" + companyName + "',"
                + "'" + o.getOrderTotal() + "',"
                + "'" + o.getStatus() + "'"
                + ")", Statement.RETURN_GENERATED_KEYS);
        ResultSet rs = smt.getGeneratedKeys();
        if (rs.next()) {
            orderId = rs.getInt(1);
            o.setOrderId(orderId);
        }
    } catch (Exception ex) {
        System.out.println("Error writing order: " + ex.getMessage());
    } finally {
        return orderId;
    }
}

// Method to register a new customer in the database
public boolean registerCustomer(Customer customer) {
  try {
      // Establish database connection
      Class.forName(driver);
      Connection conn = DriverManager.getConnection(connectionString);
      String query = "INSERT INTO Customers (companyId, companyName, addressLine1, addressLine2, town, postcode, cardNumber, expireDates, cvc) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
      PreparedStatement statement = conn.prepareStatement(query);
      // Set parameters for the prepared statement
      statement.setInt(1, customer.getCompanyId());
      statement.setString(2, customer.getCompanyName());
      statement.setString(3, customer.getAddressLine1());
      statement.setString(4, customer.getAddressLine2());
      statement.setString(5, customer.getTown());
      statement.setString(6, customer.getPostcode());
        statement.setString(7, customer.getCardNumber());
      statement.setString(8, customer.getExpireDates()); 
      statement.setString(9, customer.getCvc());
      // Execute the prepared statement
      int rowsAffected = statement.executeUpdate();
      return rowsAffected > 0;
  } catch (ClassNotFoundException | SQLException ex) {
      System.out.println("Error registering customer: " + ex.getMessage());
      return false;
  }
}

// Method to load customers from the database
public HashMap<String, Customer> loadCustomers() {
  HashMap<String, Customer> loadCustomers = new HashMap<>();
  try {
      // Establish database connection
      Class.forName(driver);
      Connection conn = DriverManager.getConnection(connectionString);
      Statement stmt = conn.createStatement();
      // Execute SQL query to retrieve customers
      ResultSet rs = stmt.executeQuery("SELECT * FROM Customers");
      while (rs.next()) {
          // Extract data from the result set
          Integer companyId = rs.getInt("CompanyId");
          String companyName = rs.getString("CompanyName");
          String addressLine1 = rs.getString("AddressLine1");
          String addressLine2 = rs.getString("AddressLine2");
          String town = rs.getString("Town");
          String postcode = rs.getString("Postcode");
          String cardNumber = rs.getString("CardNumber");
          String expireDates = rs.getString("ExpireDates");
          String cvc = rs.getString("CVC");
          String email = rs.getString("Email");
          String emailPassword = rs.getString("EmailPassword");

          // Create a new Customer object
          Customer customer = new Customer(companyId, companyName, addressLine1, addressLine2, town, postcode, cardNumber, expireDates, cvc, email, emailPassword, new HashMap<>());
          loadCustomers.put(companyId.toString(), customer);
      }
  } catch (ClassNotFoundException | SQLException ex) {
      System.out.println("Error loading customer: " + ex.getMessage());
  }
  
  return loadCustomers;
}

// Method for staff login
public Staff staffLogin(String username,String password){
    // Load staff members from the database
    HashMap<String, Staff> loadedStaff = loadStaff();
    // Check if the username exists
    if(loadedStaff.containsKey(username)){
        // Retrieve the staff member with the given username
        Staff staffWithThatUsername = loadedStaff.get(username);
        // Check if the password matches
        if(staffWithThatUsername.getPassword().equals(password)){
            return staffWithThatUsername;
        }
        else{
            return null;
        }
    }
    else{
        return null;
    }
} 
   
  // Method to load staff members from the database
public HashMap<String, Staff> loadStaff() {
    HashMap<String, Staff> loadStaff = new HashMap<>();
    try {
        // Establish database connection
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(connectionString);
        Statement stmt = conn.createStatement();
        // Execute SQL query to retrieve staff members
        ResultSet rs = stmt.executeQuery("SELECT * FROM Staff");
        while (rs.next()) {
            // Extract data from the result set
            String Username = rs.getString("Username");
            String Password = rs.getString("Password");
            String firstNameIn = rs.getString("FirstName");
            String lastNameIn = rs.getString("LastName");
            String Position = rs.getString("Position");
            double Salary = rs.getDouble("Salary");
            String staffEmailIn = rs.getString("StaffEmail"); // Retrieve StaffEmail
            
            // Create a new Staff object
            Staff staff = new Staff(Username, Password, firstNameIn, lastNameIn, Position, Salary, staffEmailIn);
            loadStaff.put(Username, staff);
        }
    } catch (Exception ex) {
        System.out.println("Error loading staff: " + ex.getMessage());
    }
    return loadStaff;
}

// Method to add a new product to the database
public boolean addProduct(Product newProduct) {
    try {
        // Load JDBC driver and establish database connection
        Class.forName(driver);
        int rowsAffected;
        try (Connection conn = DriverManager.getConnection(connectionString)) {
            // Prepare SQL statement for inserting new product
            String sqlQuery = "INSERT INTO Products (ProductName, Price, StockLevel, Measurement, Size) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sqlQuery, Statement.RETURN_GENERATED_KEYS)) {
                // Set values for the prepared statement
                preparedStatement.setString(1, newProduct.getProductName());
                preparedStatement.setDouble(2, newProduct.getPrice());
                preparedStatement.setInt(3, newProduct.getStockLevel());
                if (newProduct instanceof Furniture) {
                    Furniture furniture = (Furniture) newProduct;
                    preparedStatement.setString(4, furniture.getMeasurement()); // Set measurement for Furniture
                    preparedStatement.setNull(5, java.sql.Types.VARCHAR);
                } else if (newProduct instanceof Supplies) {
                    Supplies supplies = (Supplies) newProduct;
                    preparedStatement.setNull(4, java.sql.Types.VARCHAR);
                    preparedStatement.setString(5, supplies.getSize()); // Use getSize() as String
                }
                // Execute the SQL statement
                rowsAffected = preparedStatement.executeUpdate();
                
                // Check if any row was affected
                if (rowsAffected > 0) {
                    // Retrieve the generated keys
                    try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                        if (generatedKeys.next()) {
                            int productId = generatedKeys.getInt(1);
                            System.out.println("Generated ProductId: " + productId);
                            // Set the ProductId of the new product
                            newProduct.setProductId(productId);
                        }
                    }
                }
            }
        }
        // Return true if insertion was successful
        return rowsAffected > 0;
    } catch (SQLException | ClassNotFoundException ex) {
        // Handle exceptions
        System.out.println("Error adding product: " + ex.getMessage());
        return false;
    }
}

// Method to update staff details in the database
public void updateStaff(Staff staffToEdit, String username) {
    try {
        // Connect to the database
        Connection conn = getConnection();
        
        // Prepare the update statement
        String sql = "UPDATE staff SET username = ?, password = ?, firstName = ?, lastName = ?, position = ?, salary = ?, staffEmail = ? WHERE username = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, staffToEdit.getUsername());
        statement.setString(2, staffToEdit.getPassword());
        statement.setString(3, staffToEdit.getFirstName());
        statement.setString(4, staffToEdit.getLastName());
        statement.setString(5, staffToEdit.getPosition());
        statement.setDouble(6, staffToEdit.getSalary());
        statement.setString(7, staffToEdit.getStaffEmail()); // Add StaffEmail
        statement.setString(8, username); // Using the passed username parameter
        
        // Execute the update statement
        int rowsUpdated = statement.executeUpdate();
        
        // Close the statement (the connection will be closed automatically)
        statement.close();
        
        if (rowsUpdated > 0) {
            // Success message
            System.out.println("Staff details updated successfully.");
        } else {
            // No rows were updated
            System.out.println("No staff member found with the provided username.");
        }
    } catch (SQLException ex) {
        // Exception handling
        ex.printStackTrace();
    }
}

// Method to add a new staff member to the database
public void addStaff(Staff newStaff) {
    try {
        // Connect to the database
        Connection conn = getConnection();
        
        // Prepare the insert statement
        String sql = "INSERT INTO staff (username, password, firstName, lastName, position, salary, staffEmail) VALUES (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, newStaff.getUsername());
        statement.setString(2, newStaff.getPassword());
        statement.setString(3, newStaff.getFirstName());
        statement.setString(4, newStaff.getLastName());
        statement.setString(5, newStaff.getPosition());
        statement.setDouble(6, newStaff.getSalary());
        statement.setString(7, newStaff.getStaffEmail()); // Add StaffEmail
        
        // Execute the insert statement
        int rowsInserted = statement.executeUpdate();
        
        // Close the statement (the connection will be closed automatically)
        statement.close();
        
        if (rowsInserted > 0) {
            // Success message
            System.out.println("New staff member added successfully.");
        } else {
            // Insert failed
            System.out.println("Failed to add new staff member.");
        }
    } catch (SQLException ex) {
        // Exception handling
        ex.printStackTrace();
    }
}


// Method to delete a staff member from the database
public boolean deleteStaff(String username) {
    try {
        // Connect to the database
        Connection conn = getConnection();
        
        // Prepare the delete statement
        String sql = "DELETE FROM staff WHERE username = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, username);
        
        // Execute the delete statement
        int rowsDeleted = statement.executeUpdate();
        
        // Close the statement (the connection will be closed automatically)
        statement.close();
        
        if (rowsDeleted > 0) {
            // Success message
            System.out.println("Staff member deleted successfully.");
            return true;
        } else {
            // No staff member found with the provided username
            System.out.println("No staff member found with the provided username.");
            return false;
        }
    } catch (SQLException ex) {
        // Exception handling
        ex.printStackTrace();
        return false;
    }
}

// Method to check if bank details exist in the database
public boolean checkBankDetails(String cardNumber, String expireDate, String cvc) {
    String sql = "SELECT COUNT(*) FROM Customers WHERE cardNumber = ? AND expireDates = ? AND cvc = ?";
    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, cardNumber);
        pstmt.setString(2, expireDate);
        pstmt.setString(3, cvc);

        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            return rs.getInt(1) > 0;
        }
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
    return false;
}

// Method to retrieve all orders from the database
public HashMap<Integer, Order> getAllOrders() {
    HashMap<Integer, Order> orders = new HashMap<>();
    try {
        Connection conn = getConnection();
        Statement statement = conn.createStatement();
        ResultSet rs = statement.executeQuery("SELECT * FROM Orders");

        while (rs.next()) {
            int orderId = rs.getInt("OrderId");
            Date orderDate = rs.getDate("OrderDate");
            double orderTotal = rs.getDouble("OrderTotal");
            String status = rs.getString("Status");
            String companyName = rs.getString("CompanyName");
            // Create a new Order object
            Order order = new Order(orderId, orderDate, orderTotal, status);
            // Set the company name
            order.setCompanyName(companyName);
            // Add the order to the HashMap
            orders.put(orderId, order);
        }

        // Load order lines for each order
        for (Map.Entry<Integer, Order> entry : orders.entrySet()) {
            int orderId = entry.getKey();
            Order order = entry.getValue();
            loadOrderLines(orderId, order);
        }

    } catch (SQLException ex) {
        System.out.println("Error getting all orders: " + ex.getMessage());
    }
    return orders;
}

// Method to delete an order from the database
public void deleteOrder(int orderId) {
    try {
        Connection conn = getConnection();
        PreparedStatement statement = conn.prepareStatement("DELETE FROM Orders WHERE OrderId = ?");
        statement.setInt(1, orderId);
        int rowsDeleted = statement.executeUpdate();
        if (rowsDeleted > 0) {
            System.out.println("Order deleted successfully.");
        } else {
            System.out.println("No order found with the provided OrderId.");
        }
    } catch (SQLException ex) {
        System.out.println("Error deleting order: " + ex.getMessage());
    }
}

// Method to update order details in the database
public void updateOrder(Order order) {
    try {
        Connection conn = getConnection();
        PreparedStatement statement = conn.prepareStatement("UPDATE Orders SET OrderDate = ?, OrderTotal = ?, Status = ? WHERE OrderId = ?");
        statement.setDate(1, new java.sql.Date(order.getOrderDate().getTime()));
        statement.setDouble(2, order.getOrderTotal());
        statement.setString(3, order.getStatus());
        statement.setInt(4, order.getOrderId());
        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("Order details updated successfully.");
        } else {
            System.out.println("No order found with the provided OrderId.");
        }
    } catch (SQLException ex) {
        System.out.println("Error updating order: " + ex.getMessage());
    }
}

// Method to retrieve an order by its ID from the database
public Order getOrderById(int orderId) {
    Order order = null;
    try {
        Connection conn = getConnection();
        PreparedStatement statement = conn.prepareStatement("SELECT * FROM Orders WHERE OrderId = ?");
        statement.setInt(1, orderId);
        ResultSet rs = statement.executeQuery();
        if (rs.next()) {
            Date orderDate = rs.getDate("OrderDate");
            double orderTotal = rs.getDouble("OrderTotal");
            String status = rs.getString("Status");
            String companyName = rs.getString("CompanyName");
            // Create a new Order object
            order = new Order(orderId, orderDate, orderTotal, status);
            // Set the company name
            order.setCompanyName(companyName);
            // Load order lines for this order
            loadOrderLines(orderId, order);
        } else {
            System.out.println("No order found with the provided OrderId.");
        }
    } catch (SQLException ex) {
        System.out.println("Error getting order by Id: " + ex.getMessage());
    }
    return order;
}


// Method to update customer details in the database
public void updateCustomer(Customer customer) {
    try {
        Connection conn = getConnection();
        // Define the SQL query to update customer details
        String query = "UPDATE Customers SET companyName = ?, addressLine1 = ?, addressLine2 = ?, town = ?, postcode = ?, cardNumber = ?, expireDates = ?, cvc = ? WHERE companyCode = ?";
        PreparedStatement statement = conn.prepareStatement(query);
        // Set values for the parameters in the query
        statement.setString(1, customer.getCompanyName());
        statement.setString(2, customer.getAddressLine1());
        statement.setString(3, customer.getAddressLine2());
        statement.setString(4, customer.getTown());
        statement.setString(5, customer.getPostcode());
        statement.setString(6, customer.getCardNumber());
        statement.setString(8, customer.getExpireDates());
        statement.setString(9, customer.getCvc());
        statement.setInt(10, customer.getCompanyId());
        
        // Execute the update statement
        int rowsUpdated = statement.executeUpdate();
        
        // Check if any rows were updated
        if (rowsUpdated > 0) {
            System.out.println("Customer details updated successfully.");
        } else {
            System.out.println("No customer found with the provided company code.");
        }
        
        // Close the statement
        statement.close();
    } catch (SQLException ex) {
        System.out.println("Error updating customer details: " + ex.getMessage());
    }
}

// Method to delete a customer from the database
public boolean deleteCustomer(String companyCode) {
    boolean success = false; // Assume deletion fails initially
    try {
        Connection conn = getConnection();
        // Define the SQL query to delete a customer
        String query = "DELETE FROM Customers WHERE companyCode = ?";
        PreparedStatement statement = conn.prepareStatement(query);
        // Set the value for the parameter in the query
        statement.setString(1, companyCode);
        
        // Execute the delete statement
        int rowsDeleted = statement.executeUpdate();
        
        // Check if any rows were deleted
        if (rowsDeleted > 0) {
            System.out.println("Customer deleted successfully.");
            success = true; // Set success to true if deletion was successful
        } else {
            System.out.println("No customer found with the provided company code.");
        }
        
        // Close the statement
        statement.close();
    } catch (SQLException ex) {
        System.out.println("Error deleting customer: " + ex.getMessage());
    }
    return success;
}

// Method to check if stock levels are sufficient for a customer's orders
public boolean checkStockLevels(Customer customer) {
    try {
        // Initialize the DBManager
        DBManager dbManager = new DBManager();

        // Load products from the database
        HashMap<Integer, Product> products = dbManager.loadProducts();

        // Get a connection to the database
        Connection conn = dbManager.getConnection();

        // Loop through each order of the customer
        for (Order order : customer.getOrders().values()) {
            // Loop through each order line of the order
            for (OrderLine orderLine : order.getOrderLines().values()) {
                // Get the product associated with the order line
                Product product = products.get(orderLine.getProduct().getProductId());

                // If the product is null or the stock level is insufficient for the order line
                if (product == null || product.getStockLevel() < orderLine.getQuantity()) {
                    // Close the connection
                    conn.close();

                    // Return false indicating that stock levels are insufficient
                    return false;
                }
            }
        }

        // Close the connection
        conn.close();

        // Return true indicating that stock levels are sufficient for all order lines
        return true;
    } catch (SQLException ex) {
        System.out.println("Error checking stock levels: " + ex.getMessage());
        return false;
    }

}

// Method to get the stock level of a product by its ID
public int getProductStock(int productId) {
    int stockLevel = 0;
    String sql = "SELECT stockLevel FROM products WHERE productId = ?";
    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        // Set the value for the parameter in the query
        pstmt.setInt(1, productId);
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                stockLevel = rs.getInt("stockLevel");
            }
        }
    } catch (SQLException ex) {
        System.out.println("Error retrieving product stock level: " + ex.getMessage());
    }
    return stockLevel;
}

    
    // Method to store payment details into the database
public boolean storePaymentDetails(String companyName, double total, String cardNumber, String expireDate, String cvc) {
    boolean success = false; // Assume payment storage fails initially
    Connection conn = null;
    PreparedStatement pstmt = null;

    try {
        conn = getConnection();
        // Define the SQL query to insert payment details
        String query = "INSERT INTO Payments (CompanyName, Total, CardNumber, ExpireDate, CVC) VALUES (?, ?, ?, ?, ?)";
        pstmt = conn.prepareStatement(query);
        // Set values for the parameters in the query
        pstmt.setString(1, companyName);
        pstmt.setDouble(2, total);
        pstmt.setString(3, cardNumber);
        pstmt.setString(4, expireDate);
        pstmt.setString(5, cvc);

        // Execute the insert statement
        int rowsAffected = pstmt.executeUpdate();
        success = rowsAffected > 0;
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        try {
            // Close the prepared statement and connection
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return success;
}

// Method to get the password by username or full name
public String getPassword(String userName, String firstName, String lastName) {
    String fullName = firstName + " " + lastName; // Concatenate first and last names to form full name
    String sql = "SELECT password FROM Staff WHERE username = ? OR (firstName = ? AND lastName = ?)";
    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        // Set values for the parameters in the query
        pstmt.setString(1, userName);
        pstmt.setString(2, firstName);
        pstmt.setString(3, lastName);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            return rs.getString("password");
        }
    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
    return null;
}

// Method to retrieve furniture products from the database
public List<Product> getFurnitureProducts() {
    List<Product> products = new ArrayList<>();
    try {
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(connectionString);
        Statement smt = conn.createStatement();
        ResultSet rs = smt.executeQuery("SELECT * FROM Products WHERE Measurement IS NOT NULL AND Measurement != ''");
        while (rs.next()) {
            // Extract product details from the result set
            int productId = rs.getInt("ProductId");
            String productName = rs.getString("ProductName");
            double price = rs.getDouble("Price");
            int stockLevel = rs.getInt("StockLevel");
            String measurement = rs.getString("Measurement");
            // Create Furniture object and add to the list
            Furniture furniture = new Furniture(productId, productName, price, stockLevel, measurement);
            products.add(furniture);
        }
    } catch (Exception ex) {
        System.out.println("Error loading furniture products: " + ex.getMessage());
    }
    return products;
}

// Method to retrieve supplies products from the database
public List<Product> getSuppliesProducts() {
    List<Product> products = new ArrayList<>();
    try {
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(connectionString);
        Statement smt = conn.createStatement();
        ResultSet rs = smt.executeQuery("SELECT * FROM Products WHERE Measurement IS NULL OR Measurement = ''");
        while (rs.next()) {
            // Extract product details from the result set
            int productId = rs.getInt("ProductId");
            String productName = rs.getString("ProductName");
            double price = rs.getDouble("Price");
            int stockLevel = rs.getInt("StockLevel");
            String size = rs.getString("Size");
            // Create Supplies object and add to the list
            Supplies supplies = new Supplies(productId, productName, price, stockLevel, "", size);
            products.add(supplies);
        }
    } catch (Exception ex) {
        System.out.println("Error loading supplies products: " + ex.getMessage());
    }
    return products;
}

// Method to update customer bank details in the database
public boolean updateCustomerBankDetails(Customer customer) {
    try (Connection conn = getConnection()) {
        // Define the SQL query to update customer bank details
        String sql = "UPDATE Customers SET CardNumber = ?, ExpireDates = ?, CVC = ? WHERE CompanyName = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            // Set values for the parameters in the query
            pstmt.setString(1, customer.getCardNumber());
            pstmt.setString(2, customer.getExpireDates());
            pstmt.setString(3, customer.getCvc());
            pstmt.setString(4, customer.getCompanyName());
            // Execute the update statement
            pstmt.executeUpdate();
            return true;
        }
    } catch (SQLException e) {
        System.out.println(e.getMessage());
        return false;
    }
}

// Method to check if a username exists in the database
public boolean isUsernameExists(String username) {
    try {
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(connectionString);
        PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Customers WHERE CompanyName = ?");
        // Set the value for the parameter in the query
        pstmt.setString(1, username);
        ResultSet rs = pstmt.executeQuery();
        return rs.next(); // If any row is returned, username exists
    } catch (ClassNotFoundException | SQLException ex) {
        System.out.println("Error checking username existence: " + ex.getMessage());
        return false;
    }
}

// Method to check if an email exists in the database
public boolean isEmailExists(String email) {
    try {
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(connectionString);
        PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM Customers WHERE Email = ?");
        // Set the value for the parameter in the query
        pstmt.setString(1, email);
        ResultSet rs = pstmt.executeQuery();
        return rs.next(); // If any row is returned, email exists
    } catch (ClassNotFoundException | SQLException ex) {
        System.out.println("Error checking email existence: " + ex.getMessage());
        return false;
    }
}
}




