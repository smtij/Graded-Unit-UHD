package models;

import java.util.HashMap;

public class Customer extends User {
    // Attributes
    private Integer companyId;  
    private String companyName;
    private String addressLine1;
    private String addressLine2;
    private String town;
    private String postcode;
    private boolean isRegistered;
    private String cardNumber;
    private String expireDates;
    private String cvc;
    private String email;         
    private String emailPassword; 
    private HashMap<Integer, Order> orders;

    // Constructors
    public Customer(String companyName, String addressLine1, String addressLine2, String town, String postcode,
                    String cardNumber, String expireDates, String cvc, String email, String emailPassword) {
        super();
        this.companyId = 0;
        this.companyName = companyName;
        this.addressLine1 = addressLine1;
        this.addressLine2 = addressLine2;
        this.town = town;
        this.postcode = postcode;
        this.cardNumber = cardNumber;
        this.expireDates = expireDates;
        this.cvc = cvc;
        this.email = email;
        this.emailPassword = emailPassword;
        this.isRegistered = false;
        this.orders = new HashMap<>();
    }

    public Customer(String companyName, String addressLine1, String addressLine2, String town, String postcode) {
        this(companyName, addressLine1, addressLine2, town, postcode, "", "", "", "", "");
    }

    public Customer(String companyName, String addressLine1, String addressLine2, String town, String postcode, boolean isRegistered) {
        this(companyName, addressLine1, addressLine2, town, postcode, "", "", "", "", "");
        this.isRegistered = isRegistered;
    }

    public Customer(String companyName, String addressLine1, String addressLine2, String town, String postcode, boolean isRegistered, HashMap<Integer, Order> orders) {
        this(companyName, addressLine1, addressLine2, town, postcode, "", "", "", "", "");
        this.isRegistered = isRegistered;
        this.orders = orders;
    }

    public Customer(String cardNumber, String expireDates, String cvc) {
        this("", "", "", "", "", cardNumber, expireDates, cvc, "", "");
        this.companyId = 0;
        this.orders = new HashMap<>();
    }

    public Customer(Integer companyId, String companyName, String addressLine1, String addressLine2, String town, String postcode,
                    String cardNumber, String expireDates, String cvc, String email, String emailPassword, HashMap<Integer, Order> orders) {
        this(companyName, addressLine1, addressLine2, town, postcode, cardNumber, expireDates, cvc, email, emailPassword);
        this.companyId = companyId;
        this.orders = orders;
    }

    // Getter methods
    public Integer getCompanyId() {
        return companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public String getTown() {
        return town;
    }

    public String getPostcode() {
        return postcode;
    }

    public boolean getIsRegistered() {
        return isRegistered;
    }

    public HashMap<Integer, Order> getOrders() {
        return orders;
    }
    
    public String getCardNumber() {
        return cardNumber;
    }

    public String getExpireDates() {
        return expireDates;
    }

    public String getCvc() {
        return cvc;
    }

    public String getEmail() {
        return email;
    }

    public String getEmailPassword() {
        return emailPassword;
    }

    // Setter methods
    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public void setIsRegistered(boolean isRegistered) {
        this.isRegistered = isRegistered;
    }

    public void setOrders(HashMap<Integer, Order> orders) {
        this.orders = orders;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public void setExpireDates(String expireDates) {
        this.expireDates = expireDates;
    }

    public void setCvc(String cvc) {
        this.cvc = cvc;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setEmailPassword(String emailPassword) {
        this.emailPassword = emailPassword;
    }

    // Method to display greeting
    public String displayGreeting() {
        return "Welcome " + this.getCompanyName() + " Enjoy Shopping!";
    }
}
