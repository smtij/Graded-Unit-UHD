/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author Jason
 */
public class Category {
     private String categoryName;
     private int categoryId;

    // Default constructor
    public Category(int par, String furniture) {
    }

    // Constructor with parameters
    public Category(String categoryName,int categoryId) {
        this.categoryName = categoryName;
         this.categoryId = categoryId;
    }

    // Getter for name
    public String getCategoryName() {
        return categoryName;
    }
    
     public int getCategoryId() {
        return categoryId;
    }
    // Setter for name
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
     
}
