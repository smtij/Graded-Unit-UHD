package models;

public class OrderLine {
    private int orderLineId;
    private Product product;
    private int quantity;
    private double lineTotal;
    
    // Constructor with line total calculation
    public OrderLine(int orderLineId, Product product, int quantity, double lineTotal1) {
        this.orderLineId = orderLineId;
        this.product = product;
        this.quantity = quantity;
        this.lineTotal = product.getPrice() * quantity;
    }

    // Getter methods
    public int getOrderLineId() {
        return orderLineId;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getLineTotal() {
        return lineTotal;
    }

    // Additional getter methods for accessing product details
    public int getProductId() {
        return product.getProductId();
    }

    public String getProductName() {
        return product.getProductName();
    }

    public double getProductPrice() {
        return product.getPrice();
    }

    // Setter methods
    public void setOrderLineId(int orderLineId) {
        this.orderLineId = orderLineId;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        this.lineTotal = product.getPrice() * quantity; // Recalculate line total
    }

    public void setLineTotal(double lineTotal) {
        this.lineTotal = lineTotal;
    }

    // Implementing hashCode() and equals() methods
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + orderLineId;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OrderLine other = (OrderLine) obj;
        if (orderLineId != other.orderLineId)
            return false;
        return true;
    }
}
