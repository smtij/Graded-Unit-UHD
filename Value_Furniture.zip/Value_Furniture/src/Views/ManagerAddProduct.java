/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Views;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale.Category;
import javax.swing.DefaultListModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import models.DBManager;
import models.Product;
import models.Furniture;
import models.Customer;
import models.Manager;
import models.Supplies;
import models.Order;
import models.Staff;



/**
 *ManagerAddProduct class represents the GUI for adding products by a manager.
 * @author 30190531
 */
public class ManagerAddProduct extends javax.swing.JFrame {
       // Variables declaration
       private Product productSelected; 
       private Staff loggedInStaff;
       private String selectedCategory;
       private ManagerViewProducts previousFrame;
       /**
     * Creates new form 
     * @param product
     * @param customer
     * @param category
     * @param order
     * @param loggedInStaff
     * @param productId
     */
    public ManagerAddProduct(Staff loggedInStaff, String category) {
        this.loggedInStaff = loggedInStaff;
        this.selectedCategory = category; 
        initComponents();

        // Set custom cell renderer for the price column
       DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
       renderer.setHorizontalAlignment(SwingConstants.RIGHT); // Align text to the right
       tblProducts.getColumnModel().getColumn(2).setCellRenderer(renderer);

      DecimalFormat formatter = new DecimalFormat("$0.00");
      tblProducts.getColumnModel().getColumn(2).setCellRenderer(new DefaultTableCellRenderer() {
    @Override
    protected void setValue(Object value) {
        if (value instanceof Number) {
            value = formatter.format(value);
        }
        super.setValue(value);
    }
});
        loadProductsIntoTable();
    }
    /**
     * Set the previous frame for navigation.
     * @param frame The previous frame
     */
    public void setPreviousFrame(ManagerViewProducts frame) {
        this.previousFrame = frame;
    }
    
   /**
     * Load products into the table based on the selected category.
     */
    private void loadProductsIntoTable() {
        DBManager dbManager = new DBManager();
        List<Product> products = new ArrayList<>();

        DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
        model.setRowCount(0); // Clear existing rows

        // Fetch products based on selected category
        if (selectedCategory.equals("Furniture")) {
            products = dbManager.getFurnitureProducts();
        } else if (selectedCategory.equals("Supplies")) {
            products = dbManager.getSuppliesProducts();
        }

        // Populate the table with products
        for (Product product : products) {
            if (product instanceof Furniture) {
                Furniture furniture = (Furniture) product;
                model.addRow(new Object[]{product.getProductId(), product.getProductName(), product.getPrice(),
                    product.getStockLevel(), furniture.getMeasurement(), ""});
            } else if (product instanceof Supplies) {
                Supplies supplies = (Supplies) product;
                model.addRow(new Object[]{product.getProductId(), product.getProductName(), product.getPrice(),
                    product.getStockLevel(), "", supplies.getSize()});
            }
        }
    }
    
  /**
     * Load details of the selected product into the form.
     */
    private void loadProductDetails() {
        if (productSelected != null) {
            txtName.setText(productSelected.getProductName());
            txtPrice.setText(String.valueOf(productSelected.getPrice()));
            txtStock.setText(String.valueOf(productSelected.getStockLevel()));

            // Check the type of Product and set the corresponding attributes
            if (productSelected instanceof Furniture) {
                Furniture furniture = (Furniture) productSelected;
                txtExtra.setText(furniture.getMeasurement());
                lblExtra.setText("Measurement:");
            } else if (productSelected instanceof Supplies) {
                Supplies supplies = (Supplies) productSelected;
                txtExtra.setText(supplies.getSize());
                lblExtra.setText("Size:");
            }
        }
    }

/**
     * Check if the provided measurement format is valid for Furniture.
     * @param measurement The measurement to validate
     * @return true if valid, false otherwise
     */    
// Helper method to validate measurement format for Furniture (e.g., "50x40x60")
    private boolean isValidMeasurement(String measurement) {
        return measurement.matches("\\d+x\\d+x\\d+");
    }

 /**
     * Check if the provided size format is valid for Supplies.
     * @param size The size to validate
     * @return true if valid, false otherwise
     */    
// Helper method to validate size format for Supplies (e.g., "6mm", "10cm")
    private boolean isValidSize(String size) {
        return size.matches("\\d+(mm|cm|m)");
    }

  
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtPrice = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtStock = new javax.swing.JTextField();
        lblExtra = new javax.swing.JLabel();
        txtExtra = new javax.swing.JTextField();
        btnBack = new javax.swing.JButton();
        btnSubmit = new javax.swing.JButton();
        lblConfirmation = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblProducts = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("-------ADD PRODUCTS-------");

        jLabel3.setText("Name:");

        jLabel4.setText("Price:");

        jLabel5.setText("Stock:");

        lblExtra.setText("Extra:");

        btnBack.setText("Back To Staff Select Products");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnSubmit.setText("Submit");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });

        lblConfirmation.setText("Confirmation:");

        tblProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Name", "Price", "Stock Level", "Measurement", "Size"
            }
        ));
        jScrollPane2.setViewportView(tblProducts);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnSubmit))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnBack))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(18, 18, 18)
                                .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(lblExtra)
                                .addGap(18, 18, 18)
                                .addComponent(txtExtra, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 505, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblConfirmation)))
                .addContainerGap(75, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblExtra)
                            .addComponent(txtExtra, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSubmit)
                        .addGap(18, 18, 18)
                        .addComponent(btnBack))
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addComponent(lblConfirmation)
                .addGap(32, 32, 32))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

      /**
     * Action performed when the Submit button is clicked.
     * @param evt ActionEvent
     */
    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
     // Get product details from the form
    String name = txtName.getText();
    String priceText = txtPrice.getText();
    String stockText = txtStock.getText();
    String extra = txtExtra.getText();

    // Check if any of the required fields are empty
    if (name.isEmpty() || priceText.isEmpty() || stockText.isEmpty() || extra.isEmpty()) {
        lblConfirmation.setText("Please fill in all fields.");
        return; // Exit the method early
    }

    try {
        // Parse numeric values
        double price = Double.parseDouble(priceText);
        int stock = Integer.parseInt(stockText);

        // Validate the extra attribute based on selected category
        Product newProduct = null;
        boolean isValid = true;
        if (selectedCategory.equals("Furniture")) {
            if (isValidMeasurement(extra)) {
                newProduct = new Furniture(name, price, stock, extra);
            } else {
                isValid = false;
                lblConfirmation.setText("Invalid measurement format for Furniture (expected: 50x40x60).");
            }
        } else if (selectedCategory.equals("Supplies")) {
            if (isValidSize(extra)) {
                newProduct = new Supplies(name, price, stock, extra);
            } else {
                isValid = false;
                lblConfirmation.setText("Invalid size format for Supplies (expected: 6mm, 10cm).");
            }
        }

        // Add the product to the database if valid
        if (isValid && newProduct != null) {
            DBManager dbManager = new DBManager();
            boolean success = dbManager.addProduct(newProduct);

            // Show confirmation message
            if (success) {
                lblConfirmation.setText("Product Added Successfully");
            } else {
                lblConfirmation.setText("Error Adding Product");
            }
        }
    } catch (NumberFormatException e) {
        // Handle invalid numeric input
        lblConfirmation.setText("Invalid numeric input.");
    }
                                             

    }//GEN-LAST:event_btnSubmitActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        ManagerViewProducts selectProducts = new ManagerViewProducts(loggedInStaff);
        selectProducts.setVisible(true);
        this.dispose();
        
    }//GEN-LAST:event_btnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ManagerAddProduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ManagerAddProduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ManagerAddProduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ManagerAddProduct.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                //Product productSelected; 
                //productSelected = getProductById(productId);
                //new StaffEditProduct(productSelected).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblConfirmation;
    private javax.swing.JLabel lblExtra;
    private javax.swing.JTable tblProducts;
    private javax.swing.JTextField txtExtra;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextField txtStock;
    // End of variables declaration//GEN-END:variables
}
